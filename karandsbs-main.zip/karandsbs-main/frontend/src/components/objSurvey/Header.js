import React from "react";

export default function Header() {
  return (
    <div>
      <header>
        <h3 className="mt-3 bg-primary text-light p-3">KARANDS</h3>
      </header>
    </div>
  );
}
