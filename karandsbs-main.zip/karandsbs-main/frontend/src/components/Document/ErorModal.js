import React from 'react';

export default function ErorModal() {
    return (
        <div>
            <div class="loading-overlay">

                <div class="loading-message">
                    
                        <p class="type">Appointment</p>
                        <p class="message-type">Your adhaar is not valid </p>

                </div>
            </div>
        </div>
    )
}
