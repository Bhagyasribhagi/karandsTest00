import React from 'react'

function Header() {
  return (
    <div style={{ marginTop: "20px",backgroundColor:"transparent" }}>
      <h4>
        {/* <span class="logo black">KARANDS</span><span class="logo orange">ZONE</span> */}

      <p style={{fontSize:"25px", fontFamily: "Roboto", color: "white"}}>Select The Role You Would Like To Be!</p>
      </h4>
    </div>
  )
}

export default Header
