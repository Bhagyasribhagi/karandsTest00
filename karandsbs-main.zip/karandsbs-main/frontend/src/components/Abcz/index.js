const Abcz = () =>{
    const onHandleMouse = () => {
        console.log("ABCDDDDDDDDDDDD")
    }
    return(
        <div>
        <button onMouseEnter={onHandleMouse}>
            ABCDEFGH
        </button>
    </div>
    )
    
}

export default Abcz 