import React from "react";
//import Sidebar from '../Sidebar/Sidebar';
import ICHPDashboard from "../Dashboard/ICHPDashboard";

function Myjob() {
  return (
    <div>
      <ICHPDashboard />
      Myjob
    </div>
  );
}
export default Myjob;
