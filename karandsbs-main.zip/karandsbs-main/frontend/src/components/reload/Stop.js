function Stop() {
    return (
      <div className="end" style={{ marginTop: "25px" }}>
        <span id="caught">You Caught all the news</span>
        <br />
        <img
          style={{ width: "75px", borderRadius: "58%", marginTop: "25px" }}
          className="tickmark"
          src="https://th.bing.com/th/id/OIP.h9Otm4JCc85nuvo4kZ7yrQHaHa?pid=ImgDet&rs=1"
          alt="tick"
        />
      </div>
    );
  }
  
  export default Stop;
  