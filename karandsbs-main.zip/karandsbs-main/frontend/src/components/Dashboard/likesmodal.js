import React from 'react'

export default function Likesmodal() {

  return (
    <div>
    </div>
  )
}
