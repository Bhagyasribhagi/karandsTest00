import React from 'react';

export default function Page() {
  return (
   <div className='d-flex m-2'>
   <button className='' style={{ backgroundColor: "rgb(3, 104, 104)", color: "white"}} >Company</button>
   <button className='ms-4' style={{ backgroundColor: "rgb(3, 104, 104)", color: "white"}} >Create Company Page</button>
   </div>
  )
}
