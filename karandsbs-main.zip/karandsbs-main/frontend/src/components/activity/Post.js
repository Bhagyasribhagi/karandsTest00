import React from 'react'
import Sidebar from '../Dashboard/Sidebar'
import Details from '../Dashboard/Details'

export default function Post() {
  return (
    <div className='container-lg container-xl'>
      <div className='card mb-2'>
        <h3>users posts</h3>
      </div>
    </div>
  )
}
