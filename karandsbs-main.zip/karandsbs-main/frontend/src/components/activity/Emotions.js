import React from 'react'

export default function Emotions() {
  return (
    <div>i am watching ur emotions</div>
  )
}
