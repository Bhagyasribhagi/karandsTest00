import React from 'react';

export default function Page() {
  return (
   <div>
   <button className='btn btn-primary'>Company</button>
   <button className='btn btn-primary m-4'>Create Company Page</button>
   </div>
  )
}
