import React from 'react'

export default function DecRefBonus() {
  return (
    <div>
   <h1>Referal Bonus</h1>
    </div>
  )
}
