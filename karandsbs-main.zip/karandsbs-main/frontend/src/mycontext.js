// MyContext.js
import { createContext } from 'react';

const MyContext = createContext();

export default MyContext;
